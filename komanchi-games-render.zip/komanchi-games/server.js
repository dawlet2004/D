'use strict';
/**
 * Komanchi Games - backend (Duel + Zombi rejimi)
 * Express (statik fayllar) + Socket.IO (real vaqt)
 *
 * Qoidalar:
 *  - Bir o'yinchi xona yaratadi va 4 belgili kod oladi (chap tomondan kiradi).
 *  - Ikkinchi o'yinchi shu kod bilan kiradi (o'ng tomondan kiradi).
 *  - Ikkalasi bo'lgach 3 soniyalik sanoq, so'ng otishma boshlanadi.
 *  - Kimdir 0 jonga tushguncha o'yin davom etadi.
 *  - Barcha hisob-kitob serverda (client faqat tugma bosilganini yuboradi).
 */
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Render (va boshqa hostinglar) uchun sog'liq tekshiruvi
app.get('/healthz', (req, res) => res.type('text').send('ok'));

app.use(express.static(path.join(__dirname, 'public')));
// three.js ni npm paketidan beramiz (CDN zaxira sifatida index.html da bor)
app.get('/vendor/three.min.js', (req, res) => {
  res.sendFile(path.join(__dirname, 'node_modules', 'three', 'build', 'three.min.js'));
});

const CFG = {
  arenaX: 14,        // maydon yarim kengligi
  arenaZ: 7.5,       // maydon yarim chuqurligi
  speed: 9,          // yurish tezligi (birlik/soniya)
  bulletSpeed: 26,
  bulletLife: 1.8,   // soniya
  hitRadius: 1.0,
  damage: 20,        // 5 ta o'q = o'lim
  maxHp: 100,
  cooldown: 380,     // ms, otishlar orasidagi minimal vaqt
  tickMs: 1000 / 30,
  countdown: 3
};
const SPAWN = { left: { x: -10, z: 0 }, right: { x: 10, z: 0 } };
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const rooms = new Map();

// Zombi rejimi (hamkorlik) - alohida namespace: /zombie
require('./zombie-server').attach(io);

function genCode() {
  let code;
  do {
    code = '';
    for (let i = 0; i < 4; i++) code += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  } while (rooms.has(code));
  return code;
}

function cleanName(n, fallback) {
  n = String(n || '').replace(/[<>]/g, '').trim().slice(0, 16);
  return n || fallback;
}

function makePlayer(socket, name, side) {
  const s = SPAWN[side];
  return {
    id: socket.id, name, side,
    x: s.x, z: s.z, hp: CFG.maxHp, alive: true,
    input: { u: 0, d: 0, l: 0, r: 0 }, lastShot: 0, lastChat: 0
  };
}

function getRoom(socket) {
  const code = socket.data.room;
  return code ? rooms.get(code) : null;
}

function roomInfo(room) {
  return {
    code: room.code,
    state: room.state,
    players: room.players.map(p => ({ side: p.side, name: p.name }))
  };
}
const broadcastRoom = room => io.to(room.code).emit('room', roomInfo(room));
const sys = (room, text) => io.to(room.code).emit('chat', { sys: true, text, t: Date.now() });

function resetPlayers(room) {
  for (const p of room.players) {
    const s = SPAWN[p.side];
    p.x = s.x; p.z = s.z; p.hp = CFG.maxHp; p.alive = true;
    p.input = { u: 0, d: 0, l: 0, r: 0 };
    p.lastShot = 0;
  }
  room.bullets = [];
}

function startMatch(room) {
  if (room.players.length < 2) return;
  clearTimeout(room.cdTimer);
  resetPlayers(room);
  room.rematch.clear();
  room.winner = null;
  room.state = 'countdown';
  io.to(room.code).emit('start', {
    countdown: CFG.countdown,
    players: room.players.map(p => ({ side: p.side, name: p.name }))
  });
  sys(room, "Ikkala o'yinchi ham kirdi. Tayyor bo'ling!");
  room.cdTimer = setTimeout(() => {
    if (room.state === 'countdown') {
      room.state = 'playing';
      io.to(room.code).emit('go');
    }
  }, CFG.countdown * 1000);
}

function endMatch(room, winner) {
  room.state = 'over';
  room.winner = winner.side;
  room.bullets = [];
  io.to(room.code).emit('over', {
    winner: winner.side,
    names: Object.fromEntries(room.players.map(p => [p.side, p.name]))
  });
  sys(room, `${winner.name} g'alaba qozondi!`);
}

function tick(room) {
  const dt = CFG.tickMs / 1000;

  // 1) o'yinchilar harakati
  for (const p of room.players) {
    if (!p.alive) continue;
    let vx = p.input.r - p.input.l;
    let vz = p.input.d - p.input.u;
    const len = Math.hypot(vx, vz);
    if (len > 0) {
      p.x += (vx / len) * CFG.speed * dt;
      p.z += (vz / len) * CFG.speed * dt;
    }
    p.x = Math.max(-CFG.arenaX, Math.min(CFG.arenaX, p.x));
    p.z = Math.max(-CFG.arenaZ, Math.min(CFG.arenaZ, p.z));
  }

  // 2) o'qlar
  const alive = [];
  for (const b of room.bullets) {
    b.x += b.vx * dt;
    b.z += b.vz * dt;
    b.life -= dt;
    if (b.life <= 0 || Math.abs(b.x) > CFG.arenaX + 6 || Math.abs(b.z) > CFG.arenaZ + 6) continue;

    let hit = false;
    for (const t of room.players) {
      if (!t.alive || t.side === b.owner) continue;
      if (Math.hypot(t.x - b.x, t.z - b.z) <= CFG.hitRadius) {
        t.hp = Math.max(0, t.hp - CFG.damage);
        io.to(room.code).emit('hit', { side: t.side, x: b.x, z: b.z, hp: t.hp });
        hit = true;
        if (t.hp <= 0) {
          t.alive = false;
          const winner = room.players.find(p => p.side === b.owner);
          endMatch(room, winner);
        }
        break;
      }
    }
    if (!hit) alive.push(b);
    if (room.state !== 'playing') break;
  }
  if (room.state === 'playing') room.bullets = alive;

  // 3) holatni yuborish
  io.to(room.code).volatile.emit('state', {
    p: room.players.map(p => ({ s: p.side, x: +p.x.toFixed(2), z: +p.z.toFixed(2), hp: p.hp })),
    b: room.bullets.map(b => [b.id, +b.x.toFixed(2), +b.z.toFixed(2)])
  });
}

setInterval(() => {
  for (const room of rooms.values()) if (room.state === 'playing') tick(room);
}, CFG.tickMs);

function leaveRoom(socket) {
  const room = getRoom(socket);
  if (!room) return;
  const idx = room.players.findIndex(p => p.id === socket.id);
  const gone = idx >= 0 ? room.players.splice(idx, 1)[0] : null;
  socket.leave(room.code);
  socket.data.room = null;

  if (room.players.length === 0) {
    clearTimeout(room.cdTimer);
    rooms.delete(room.code);
    return;
  }
  clearTimeout(room.cdTimer);
  room.state = 'waiting';
  room.bullets = [];
  room.rematch.clear();
  resetPlayers(room);
  if (gone) sys(room, `${gone.name} o'yindan chiqib ketdi. Yangi raqib kutilmoqda...`);
  broadcastRoom(room);
}

io.on('connection', socket => {
  socket.data.room = null;

  socket.on('create', (name, cb) => {
    if (typeof cb !== 'function') return;
    leaveRoom(socket);
    const code = genCode();
    const player = makePlayer(socket, cleanName(name, "O'yinchi 1"), 'left'); // chap tomondan kiradi
    const room = {
      code, players: [player], bullets: [], state: 'waiting',
      nextBulletId: 1, cdTimer: null, rematch: new Set(), winner: null
    };
    rooms.set(code, room);
    socket.join(code);
    socket.data.room = code;
    cb({ ok: true, code, side: 'left', name: player.name });
    broadcastRoom(room);
    sys(room, `Xona yaratildi. Kod: ${code}`);
  });

  socket.on('join', (code, name, cb) => {
    if (typeof cb !== 'function') return;
    code = String(code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return cb({ ok: false, error: 'Bunday xona topilmadi. Kodni tekshiring.' });
    if (room.players.length >= 2) return cb({ ok: false, error: "Xona to'la." });
    leaveRoom(socket);

    const taken = room.players.map(p => p.side);
    const side = taken.includes('left') ? 'right' : 'left'; // ikkinchisi o'ng tomondan kiradi
    let nm = cleanName(name, "O'yinchi 2");
    if (room.players.some(p => p.name === nm)) nm += ' 2';
    const player = makePlayer(socket, nm, side);
    room.players.push(player);
    socket.join(code);
    socket.data.room = code;
    cb({ ok: true, code, side, name: nm });
    broadcastRoom(room);
    startMatch(room);
  });

  socket.on('input', inp => {
    const room = getRoom(socket);
    if (!room || !inp) return;
    const p = room.players.find(x => x.id === socket.id);
    if (!p) return;
    p.input = { u: +!!inp.u, d: +!!inp.d, l: +!!inp.l, r: +!!inp.r };
  });

  socket.on('shoot', () => {
    const room = getRoom(socket);
    if (!room || room.state !== 'playing') return;
    const p = room.players.find(x => x.id === socket.id);
    const t = room.players.find(x => x.id !== socket.id);
    if (!p || !t || !p.alive) return;
    const now = Date.now();
    if (now - p.lastShot < CFG.cooldown) return;
    p.lastShot = now;

    // raqibga qarab otiladi (kichik tarqalish bilan)
    const ang = Math.atan2(t.z - p.z, t.x - p.x) + (Math.random() - 0.5) * 0.08;
    const dx = Math.cos(ang), dz = Math.sin(ang);
    room.bullets.push({
      id: room.nextBulletId++,
      owner: p.side,
      x: p.x + dx * 1.6, z: p.z + dz * 1.6,
      vx: dx * CFG.bulletSpeed, vz: dz * CFG.bulletSpeed,
      life: CFG.bulletLife
    });
    io.to(room.code).emit('shot', { side: p.side });
  });

  socket.on('chat', text => {
    const room = getRoom(socket);
    if (!room) return;
    const p = room.players.find(x => x.id === socket.id);
    if (!p) return;
    const now = Date.now();
    if (now - p.lastChat < 400) return;
    p.lastChat = now;
    text = String(text || '').trim().slice(0, 200);
    if (!text) return;
    io.to(room.code).emit('chat', { name: p.name, side: p.side, text, t: now });
  });

  socket.on('rematch', () => {
    const room = getRoom(socket);
    if (!room || room.state !== 'over') return;
    room.rematch.add(socket.id);
    if (room.players.length === 2 && room.players.every(p => room.rematch.has(p.id))) {
      startMatch(room);
    } else {
      sys(room, "Qayta o'ynash so'raldi...");
    }
  });

  socket.on('leave', () => leaveRoom(socket));
  socket.on('disconnect', () => leaveRoom(socket));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Komanchi Duel ishga tushdi: http://localhost:${PORT}`);
});
