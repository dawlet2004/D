'use strict';
/**
 * Zombi rejimi (hamkorlikda) - Socket.IO namespace: /zombie
 *  - 1, 2 yoki 3 o'yinchi bitta jamoa; xona kodi bilan ulanadi
 *    (1-chi chap, 2-chi o'ng, 3-chi orqa darvozadan kirib keladi)
 *  - 60 level. Har levelda xarita KATTAROQ, zombilar ko'proq va QIYINROQ. Har 5-levelda BOSS.
 *  - Zombilardan almaz tushadi; do'konda almazga qurol sotib olinadi (hammasi serverda tekshiriladi)
 *  - Checkpoint: 5 levelni tugatgan jamoa keyingi safar o'sha joydan boshlashi mumkin
 */
const store = require('./store');
const { WEAPONS, BY_ID, UPGRADE, upgradeCost, upgraded } = require('./weapons');

const MAX_LEVEL = 60;
const MAX_PLAYERS = 3;
const SIDES = ['left', 'right', 'back'];
const CFG = {
  baseX: 20, baseZ: 13, growX: 0.5, growZ: 0.3,       // xarita o'lchami level bilan o'sadi
  speed: 7.5, tickMs: 1000 / 30, countdown: 3, enterTime: 2.8,
  maxHp: 100, maxBullets: 600, maxGems: 90, gemLife: 25, pickRadius: 1.8,
  gameBonus: 10, winBonus: 500, interTime: 6
};
const SPAWN = { left: { x: -3, z: 0 }, right: { x: 3, z: 0 }, back: { x: 0, z: -4 } };
const TYPES = ['walker', 'runner', 'tank', 'boss'];
const ZT = {
  walker: { hp: 60,   speed: 2.4, dmg: 10, r: 0.7,  acd: 0.9, gem: [0.35, 1] },
  runner: { hp: 32,   speed: 4.8, dmg: 7,  r: 0.55, acd: 0.7, gem: [0.4, 1] },
  tank:   { hp: 320,  speed: 1.6, dmg: 26, r: 1.1,  acd: 1.2, gem: [1, 5] },
  boss:   { hp: 1800, speed: 2.0, dmg: 40, r: 1.7,  acd: 1.4, gem: [1, 40] }
};
const KINDS = ['normal', 'rocket', 'flame', 'sniper', 'laser', 'plasma'];
const WEAPON_INDEX = Object.fromEntries(WEAPONS.map((w, i) => [w.id, i]));
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const TEAM_MUL = [1, 1, 1.4, 1.8];
const r2 = v => Math.round(v * 100) / 100;
const rand = (a, b) => a + Math.random() * (b - a);
const arenaFor = n => ({ ax: CFG.baseX + (n - 1) * CFG.growX, az: CFG.baseZ + (n - 1) * CFG.growZ });

function cleanName(n, fb) {
  n = String(n || '').replace(/[<>]/g, '').trim().slice(0, 16);
  return n || fb;
}

function attach(io) {
  const ns = io.of('/zombie');
  const rooms = new Map();
  const emit = (room, ev, data) => ns.to(room.code).emit(ev, data);

  ns.use((socket, next) => {
    const pid = socket.handshake.auth && socket.handshake.auth.pid;
    if (typeof pid !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(pid)) return next(new Error('bad pid'));
    socket.data.pid = pid;
    next();
  });

  /* ---------- yordamchilar ---------- */
  function genCode() {
    let c;
    do { c = ''; for (let i = 0; i < 4; i++) c += ALPHABET[Math.floor(Math.random() * ALPHABET.length)]; }
    while (rooms.has(c));
    return c;
  }
  const getRoom = socket => (socket.data.room ? rooms.get(socket.data.room) : null);
  const getPlayer = (room, id) => room.players.find(p => p.id === id);

  function gatePos(room, side) {
    if (side === 'left') return { x: -(room.ax + 6), z: 0 };
    if (side === 'right') return { x: room.ax + 6, z: 0 };
    return { x: 0, z: -(room.az + 6) };
  }
  function setEntering(room, p) {
    const g = gatePos(room, p.side), s = SPAWN[p.side];
    p.x = g.x; p.z = g.z; p.entering = true;
    p.enterSpeed = Math.max(8, Math.hypot(s.x - g.x, s.z - g.z) / CFG.enterTime);
  }

  function info(room) {
    return {
      code: room.code, state: room.state, maxLevel: MAX_LEVEL,
      players: room.players.map(p => {
        const pr = store.get(p.pid);
        return { side: p.side, name: p.name, host: p.id === room.hostId, weapon: pr.equipped, weaponLevel: (pr.upgrades || {})[pr.equipped] || 0, best: pr.bestWave };
      })
    };
  }
  const broadcastRoom = room => emit(room, 'room', info(room));
  const sys = (room, text) => emit(room, 'chat', { sys: true, text, t: Date.now() });

  function credit(p, v) {
    const pr = store.get(p.pid);
    pr.diamonds += v; p.gems += v;
    store.save();
    ns.to(p.id).emit('profile', { diamonds: pr.diamonds });
  }

  function newPlayer(socket, name, side) {
    return {
      id: socket.id, pid: socket.data.pid, name, side,
      x: SPAWN[side].x, z: SPAWN[side].z, hp: CFG.maxHp, alive: true, entering: false, inv: 0, enterSpeed: 8,
      input: { u: 0, d: 0, l: 0, r: 0, f: 0 }, aim: side === 'left' ? 0 : side === 'right' ? Math.PI : Math.PI / 2,
      nextShot: 0, gems: 0, kills: 0, lastChat: 0
    };
  }

  function levelAllowed(room, level) {
    if (level === 1) return true;
    if (!Number.isInteger(level) || level < 1 || level > MAX_LEVEL || (level - 1) % 5 !== 0) return false;
    return room.players.every(p => store.get(p.pid).bestWave >= level - 1);
  }

  /* ---------- o'yin oqimi ---------- */
  function startGame(room, level) {
    clearTimeout(room.cd);
    level = levelAllowed(room, level) ? level : 1;
    Object.assign(room, arenaFor(level));
    room.state = 'countdown';
    room.zombies = []; room.bullets = []; room.gems = [];
    room.wave = level - 1; room.startLevel = level; room.kills = 0;
    room.toSpawn = []; room.inter = 0; room.spawnT = 0; room.spawnGap = 1;
    for (const p of room.players) {
      p.hp = CFG.maxHp; p.alive = true; p.inv = 0; p.gems = 0; p.kills = 0; p.nextShot = 0;
      p.input = { u: 0, d: 0, l: 0, r: 0, f: 0 };
      setEntering(room, p);
    }
    emit(room, 'start', { countdown: CFG.countdown, level, ax: room.ax, az: room.az });
    broadcastRoom(room);
    room.cd = setTimeout(() => {
      if (room.state === 'countdown') {
        room.state = 'playing'; room.inter = 0.8;
        emit(room, 'go', {});
        broadcastRoom(room);
      }
    }, CFG.countdown * 1000);
  }

  function pickType(n) {
    const r = Math.random();
    const tank = n >= 3 ? Math.min(0.2, 0.03 + n * 0.006) : 0;
    const run = n >= 2 ? Math.min(0.45, 0.1 + n * 0.01) : 0;
    if (r < tank) return 'tank';
    if (r < tank + run) return 'runner';
    return 'walker';
  }

  function startWave(room) {
    const n = ++room.wave;
    Object.assign(room, arenaFor(n));
    const boss = n % 5 === 0;
    let count = Math.min(100, Math.round((5 + n * 1.6) * TEAM_MUL[room.players.length]));
    if (boss) count = Math.ceil(count * 0.6);
    room.toSpawn = [];
    if (boss) for (let i = 0; i < 1 + Math.floor(n / 25); i++) room.toSpawn.push('boss');
    for (let i = 0; i < count; i++) room.toSpawn.push(pickType(n));
    room.spawnGap = Math.max(0.15, 1.0 - n * 0.03);
    room.spawnT = 0.5;
    room.maxAlive = Math.min(75, 30 + n);
    emit(room, 'wave', { n, boss, final: n === MAX_LEVEL, count: room.toSpawn.length, ax: room.ax, az: room.az });
  }

  function spawnZ(room, type) {
    const t = ZT[type], n = room.wave, A = room.ax, B = room.az, m = 3;
    let x, z;
    switch (Math.floor(Math.random() * 4)) {
      case 0: x = rand(-A, A); z = -B - m; break;
      case 1: x = rand(-A, A); z = B + m; break;
      case 2: x = -A - m; z = rand(-B, B); break;
      default: x = A + m; z = rand(-B, B);
    }
    const hp = t.hp * (1 + (n - 1) * 0.12) * (type === 'boss' && n === MAX_LEVEL ? 2 : 1);
    room.zombies.push({
      id: room.nid++, ti: TYPES.indexOf(type), type, x, z, hp, max: hp,
      speed: t.speed * (1 + Math.min(n - 1, 40) * 0.012) * rand(0.9, 1.1),
      dmg: t.dmg * (1 + (n - 1) * 0.025), r: t.r, acd: t.acd, cd: 0
    });
  }

  function waveClear(room) {
    const n = room.wave, bonus = n * 5;
    for (const p of room.players) {
      const pr = store.get(p.pid);
      pr.bestWave = Math.max(pr.bestWave, n);
      if (p.alive) { p.hp = Math.min(CFG.maxHp, p.hp + 50); }
      else { p.alive = true; p.hp = CFG.maxHp / 2; setEntering(room, p); }   // yiqilgan o'rtoq darvozadan qaytadi
      credit(p, bonus);
    }
    store.save();
    emit(room, 'waveclear', { n, bonus });
    if (n >= MAX_LEVEL) { for (const p of room.players) credit(p, CFG.winBonus); endGame(room, true); return; }
    room.inter = CFG.interTime;
  }

  function endGame(room, win) {
    if (room.state === 'over') return;
    room.state = 'over';
    clearTimeout(room.cd);
    for (const p of room.players) {
      credit(p, CFG.gameBonus);
      const pr = store.get(p.pid);
      pr.games++; pr.kills += p.kills;
    }
    store.save();
    emit(room, 'over', {
      win: !!win, level: room.wave, kills: room.kills, bonus: CFG.gameBonus + (win ? CFG.winBonus : 0),
      players: room.players.map(p => ({ side: p.side, name: p.name, gems: p.gems, kills: p.kills }))
    });
    room.zombies = []; room.bullets = []; room.gems = [];
    broadcastRoom(room);
  }

  function damageZ(room, z, dmg, ownerSide) {
    if (z.hp <= 0) return;
    z.hp -= dmg;
    if (z.hp > 0) return;
    room.kills++;
    const owner = room.players.find(p => p.side === ownerSide);
    if (owner) owner.kills++;
    // almaz yerda qolmaydi: o'ldirgan o'yinchining hisobiga darhol qo'shiladi
    const [chance, amount] = ZT[z.type].gem;
    if (Math.random() < chance) {
      const v = amount * (1 + Math.floor(room.wave / 10));
      const taker = (owner && owner.alive) ? owner : (room.players.find(p => p.alive) || owner);
      if (taker) { credit(taker, v); emit(room, 'pick', { side: taker.side, v, x: r2(z.x), z: r2(z.z) }); }
    }
    emit(room, 'zdie', { id: z.id, x: r2(z.x), z: r2(z.z), type: z.ti });
  }

  function explode(room, b) {
    for (const z of room.zombies) {
      if (z.hp <= 0) continue;
      const reach = b.splash + z.r, d = Math.hypot(z.x - b.x, z.z - b.z);
      if (d <= reach) damageZ(room, z, b.sdmg * (1 - Math.min(1, d / reach) * 0.6), b.owner);
    }
    emit(room, 'boom', { x: r2(b.x), z: r2(b.z), r: b.splash });
  }

  function fire(room, p, w, st) {
    for (let i = 0; i < w.pellets && room.bullets.length < CFG.maxBullets; i++) {
      const a = p.aim + (Math.random() - 0.5) * w.spread;
      const dx = Math.cos(a), dz = Math.sin(a);
      room.bullets.push({
        id: room.nid++, owner: p.side,
        x: p.x + dx * 1.8, z: p.z + dz * 1.8, vx: dx * w.speed, vz: dz * w.speed,
        life: w.life, dmg: st.dmg, pierce: w.pierce, hit: new Set(),
        splash: w.splash, sdmg: st.sdmg, kind: Math.max(0, KINDS.indexOf(w.kind))
      });
    }
    emit(room, 'shot', { side: p.side, kind: w.kind, weapon: w.id });
  }

  function tick(room) {
    const dt = CFG.tickMs / 1000, now = Date.now();
    const AX = room.ax, AZ = room.az;

    // 1) o'yinchilar
    for (const p of room.players) {
      if (!p.alive) continue;
      if (p.entering) {                                  // darvozadan kirib kelish
        const s = SPAWN[p.side], dx = s.x - p.x, dz = s.z - p.z, d = Math.hypot(dx, dz), step = p.enterSpeed * dt;
        if (d <= step) { p.x = s.x; p.z = s.z; p.entering = false; p.inv = 1.5; }
        else { p.x += dx / d * step; p.z += dz / d * step; }
        continue;
      }
      if (p.inv > 0) p.inv -= dt;
      // klaviatura (0/1) va joystik (analog -1..1) birga ishlaydi
      const vx = p.input.r - p.input.l + (p.input.mx || 0), vz = p.input.d - p.input.u + (p.input.mz || 0);
      const len = Math.hypot(vx, vz);
      if (len > 0.01) { const sc = Math.min(1, len) / len; p.x += vx * sc * CFG.speed * dt; p.z += vz * sc * CFG.speed * dt; }
      p.x = Math.max(-AX, Math.min(AX, p.x));
      p.z = Math.max(-AZ, Math.min(AZ, p.z));
      if (p.input.f && now >= p.nextShot && room.state === 'playing') {
        const pr = store.get(p.pid), w = BY_ID[pr.equipped] || BY_ID.pistol;
        const st = upgraded(w, pr.upgrades[w.id] || 0);
        p.nextShot = now + st.cd;
        fire(room, p, w, st);
      }
    }

    // 2) o'qlar
    const alive = [];
    for (const b of room.bullets) {
      const n = Math.max(1, Math.ceil(Math.hypot(b.vx, b.vz) * dt / 0.45));
      const sx = b.vx * dt / n, sz = b.vz * dt / n;
      let dead = false;
      for (let s = 0; s < n && !dead; s++) {
        b.x += sx; b.z += sz;
        if (Math.abs(b.x) > AX + 8 || Math.abs(b.z) > AZ + 8) { dead = true; break; }
        for (const z of room.zombies) {
          if (z.hp <= 0 || b.hit.has(z.id)) continue;
          const rr = z.r + 0.2;
          if ((z.x - b.x) ** 2 + (z.z - b.z) ** 2 <= rr * rr) {
            b.hit.add(z.id);
            damageZ(room, z, b.dmg, b.owner);
            if (b.splash) { explode(room, b); dead = true; }
            else if (b.pierce-- <= 0) dead = true;
            break;
          }
        }
      }
      b.life -= dt;
      if (!dead && b.life <= 0) { if (b.splash) explode(room, b); dead = true; }
      if (!dead) alive.push(b);
    }
    room.bullets = alive;
    room.zombies = room.zombies.filter(z => z.hp > 0);

    // 3) zombilar
    for (const z of room.zombies) {
      if (z.cd > 0) z.cd -= dt;
      let tgt = null, bd = 1e9;
      for (const p of room.players) {
        if (!p.alive || p.entering) continue;
        const d = Math.hypot(p.x - z.x, p.z - z.z);
        if (d < bd) { bd = d; tgt = p; }
      }
      if (!tgt) continue;
      const d = Math.max(bd, 0.001), dx = tgt.x - z.x, dz = tgt.z - z.z;
      if (d > z.r + 0.5) { z.x += dx / d * z.speed * dt; z.z += dz / d * z.speed * dt; }
      if (d <= z.r + 0.8 && z.cd <= 0 && tgt.inv <= 0) {
        z.cd = z.acd;
        tgt.hp = Math.max(0, tgt.hp - z.dmg);
        emit(room, 'phit', { side: tgt.side, hp: Math.round(tgt.hp) });
        if (tgt.hp <= 0) { tgt.alive = false; emit(room, 'pdie', { side: tgt.side }); }
      }
    }
    const Z = room.zombies;                              // bir-birining ichiga kirmasin
    for (let i = 0; i < Z.length; i++) {
      for (let j = i + 1; j < Z.length; j++) {
        const a = Z[i], c = Z[j], min = (a.r + c.r) * 0.9;
        let dx = c.x - a.x, dz = c.z - a.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < min * min) {
          if (d2 < 1e-6) { dx = Math.random() - 0.5; dz = Math.random() - 0.5; }
          const d = Math.sqrt(dx * dx + dz * dz) || 1, push = (min - d) * 0.25;
          a.x -= dx / d * push; a.z -= dz / d * push; c.x += dx / d * push; c.z += dz / d * push;
        }
      }
    }
    if (room.players.length && room.players.every(p => !p.alive)) { endGame(room, false); return; }

    // 5) levellar
    if (room.state === 'playing') {
      if (room.inter > 0) {
        room.inter -= dt;
        if (room.inter <= 0) startWave(room);
      } else if (room.toSpawn.length) {
        room.spawnT -= dt;
        if (room.spawnT <= 0 && room.zombies.length < room.maxAlive) {
          spawnZ(room, room.toSpawn.shift());
          room.spawnT = room.spawnGap;
        }
      } else if (room.zombies.length === 0 && room.wave > 0) {
        waveClear(room);
        if (room.state === 'over') return;
      }
    }

    // 6) holatni yuborish
    ns.to(room.code).volatile.emit('state', {
      w: { n: room.wave, left: room.toSpawn.length + room.zombies.length, inter: Math.max(0, r2(room.inter)), ax: room.ax, az: room.az },
      p: room.players.map(p => ({
        s: p.side, x: r2(p.x), z: r2(p.z), hp: Math.round(p.hp), a: +p.alive, e: +p.entering,
        g: p.gems, aim: r2(p.aim), w: WEAPON_INDEX[store.get(p.pid).equipped] || 0,
        wl: store.get(p.pid).upgrades[store.get(p.pid).equipped] || 0
      })),
      z: room.zombies.map(z => [z.id, z.ti, r2(z.x), r2(z.z), Math.max(1, Math.ceil(z.hp / z.max * 100))]),
      b: room.bullets.map(b => [b.id, r2(b.x), r2(b.z), b.kind]),
      g: room.gems.map(g => [g.id, r2(g.x), r2(g.z), g.v])
    });
  }

  setInterval(() => {
    for (const room of rooms.values()) {
      if (room.state === 'playing' || room.state === 'countdown') {
        try { tick(room); } catch (e) { console.error('tick xatosi:', e); }
      }
    }
  }, CFG.tickMs);

  function leaveRoom(socket) {
    const room = getRoom(socket);
    if (!room) return;
    const idx = room.players.findIndex(p => p.id === socket.id);
    const gone = idx >= 0 ? room.players.splice(idx, 1)[0] : null;
    socket.leave(room.code);
    socket.data.room = null;
    if (!room.players.length) { clearTimeout(room.cd); rooms.delete(room.code); return; }
    if (room.hostId === socket.id) room.hostId = room.players[0].id;
    if (gone) sys(room, `${gone.name} o'yindan chiqib ketdi.`);
    if ((room.state === 'playing' || room.state === 'countdown') && room.players.every(p => !p.alive)) endGame(room, false);
    broadcastRoom(room);
  }

  const withCb = fn => (...args) => { if (typeof args[args.length - 1] === 'function') fn(...args); };

  /* ---------- socket hodisalari ---------- */
  ns.on('connection', socket => {
    socket.data.room = null;

    socket.on('hello', withCb((name, cb) => {
      const pr = store.get(socket.data.pid, cleanName(name, ''));
      cb({
        profile: store.view(pr), maxLevel: MAX_LEVEL, upgrade: UPGRADE,
        weapons: WEAPONS.map(w => ({ ...w, ucost: Array.from({ length: UPGRADE.max }, (_, l) => upgradeCost(w, l)) }))
      });
    }));

    /* do'kon */
    socket.on('shop:buy', withCb((id, cb) => {
      const w = BY_ID[id], pr = store.get(socket.data.pid);
      if (!w) return cb({ ok: false, error: "Bunday qurol yo'q." });
      if (pr.owned.includes(id)) return cb({ ok: false, error: 'Bu qurol sizda bor.' });
      if (pr.diamonds < w.price) return cb({ ok: false, error: `Almaz yetmaydi: yana ${w.price - pr.diamonds} ta kerak.` });
      pr.diamonds -= w.price; pr.owned.push(id); pr.equipped = id;
      store.save();
      cb({ ok: true, profile: store.view(pr) });
      const room = getRoom(socket); if (room) broadcastRoom(room);
    }));
    socket.on('shop:upgrade', withCb((id, cb) => {
      const w = BY_ID[id], pr = store.get(socket.data.pid);
      if (!w || !pr.owned.includes(id)) return cb({ ok: false, error: "Avval bu qurolni sotib oling." });
      const lvl = pr.upgrades[id] || 0;
      if (lvl >= UPGRADE.max) return cb({ ok: false, error: 'Maksimal daraja.' });
      const cost = upgradeCost(w, lvl);
      if (pr.diamonds < cost) return cb({ ok: false, error: `Almaz yetmaydi: yana ${cost - pr.diamonds} ta kerak.` });
      pr.diamonds -= cost; pr.upgrades[id] = lvl + 1;
      store.save();
      cb({ ok: true, profile: store.view(pr) });
      const room = getRoom(socket); if (room) broadcastRoom(room);
    }));
    socket.on('shop:equip', withCb((id, cb) => {
      const pr = store.get(socket.data.pid);
      if (!BY_ID[id] || !pr.owned.includes(id)) return cb({ ok: false, error: "Bu qurol sizda yo'q." });
      pr.equipped = id; store.save();
      cb({ ok: true, profile: store.view(pr) });
      const room = getRoom(socket); if (room) broadcastRoom(room);
    }));

    /* xona */
    socket.on('create', withCb((name, cb) => {
      leaveRoom(socket);
      const code = genCode();
      const nm = cleanName(name, "O'yinchi 1");
      store.get(socket.data.pid, nm);
      const room = {
        code, players: [], hostId: socket.id, state: 'lobby',
        zombies: [], bullets: [], gems: [], nid: 1, wave: 0, startLevel: 1, kills: 0,
        toSpawn: [], inter: 0, spawnT: 0, spawnGap: 1, maxAlive: 30, cd: null, ...arenaFor(1)
      };
      room.players.push(newPlayer(socket, nm, 'left'));
      rooms.set(code, room);
      socket.join(code); socket.data.room = code;
      cb({ ok: true, code, side: 'left' });
      broadcastRoom(room);
      sys(room, `Xona yaratildi. Kod: ${code}. Jamoa 3 kishigacha bo'lishi mumkin.`);
    }));

    socket.on('join', withCb((code, name, cb) => {
      code = String(code || '').trim().toUpperCase();
      const room = rooms.get(code);
      if (!room) return cb({ ok: false, error: 'Bunday xona topilmadi. Kodni tekshiring.' });
      if (room.players.length >= MAX_PLAYERS) return cb({ ok: false, error: "Xona to'la (3 kishi)." });
      leaveRoom(socket);
      const side = SIDES.find(s => !room.players.some(p => p.side === s));
      let nm = cleanName(name, `O'yinchi ${room.players.length + 1}`);
      if (room.players.some(p => p.name === nm)) nm += ' ' + (room.players.length + 1);
      store.get(socket.data.pid, nm);
      const p = newPlayer(socket, nm, side);
      if (room.state === 'playing' || room.state === 'countdown') setEntering(room, p);
      room.players.push(p);
      socket.join(code); socket.data.room = code;
      cb({ ok: true, code, side });
      broadcastRoom(room);
      sys(room, `${nm} jamoaga qo'shildi.`);
    }));

    socket.on('start', level => {
      const room = getRoom(socket);
      if (!room || room.hostId !== socket.id) return;
      if (room.state !== 'lobby' && room.state !== 'over') return;
      startGame(room, parseInt(level, 10) || 1);
      sys(room, `O'yin boshlandi: ${room.startLevel}-level. Zombilar yaqinlashmoqda!`);
    });

    socket.on('input', inp => {
      const room = getRoom(socket);
      if (!room || !inp) return;
      const p = getPlayer(room, socket.id);
      if (!p) return;
      const cl = v => Math.max(-1, Math.min(1, Number(v) || 0));
      p.input = { u: +!!inp.u, d: +!!inp.d, l: +!!inp.l, r: +!!inp.r, f: +!!inp.f, mx: cl(inp.mx), mz: cl(inp.mz) };
      if (Number.isFinite(inp.a)) p.aim = Math.max(-10, Math.min(10, inp.a));
    });

    socket.on('chat', text => {
      const room = getRoom(socket);
      if (!room) return;
      const p = getPlayer(room, socket.id);
      if (!p) return;
      const now = Date.now();
      if (now - p.lastChat < 400) return;
      p.lastChat = now;
      text = String(text || '').trim().slice(0, 200);
      if (!text) return;
      emit(room, 'chat', { name: p.name, side: p.side, text, t: now });
    });

    socket.on('leave', () => leaveRoom(socket));
    socket.on('disconnect', () => leaveRoom(socket));
  });

  return { rooms, tick, CFG };
}

module.exports = { attach, MAX_LEVEL };
