'use strict';
/**
 * Qurollar katalogi. Har bir qurolning o'z narxi (almaz) va xususiyatlari bor.
 *  dmg      - bitta o'q zarari        cd     - otishlar orasidagi vaqt (ms)
 *  pellets  - bir otishdagi o'qlar    spread - tarqalish burchagi (radian)
 *  speed    - o'q tezligi             life   - o'q umri (soniya) => masofa = speed*life
 *  pierce   - nechta qo'shimcha zombidan o'tadi
 *  splash   - portlash radiusi (raketa), sdmg - portlash zarari
 */
const WEAPONS = [
  { id: 'pistol',   name: 'Pistolet',      price: 0,    dmg: 20,  cd: 350,  pellets: 1, spread: 0.03, speed: 28, life: 1.1,  pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Oddiy boshlang'ich qurol. Arzon, ishonchli." },
  { id: 'revolver', name: 'Revolver',      price: 120,  dmg: 55,  cd: 620,  pellets: 1, spread: 0.02, speed: 32, life: 1.2,  pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Sekin, lekin har o'q kuchli." },
  { id: 'smg',      name: 'Avtomat (SMG)', price: 260,  dmg: 11,  cd: 85,   pellets: 1, spread: 0.12, speed: 28, life: 0.9,  pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Juda tez otadi. Yaqin va o'rta masofa uchun." },
  { id: 'crossbow', name: 'Arbalet',      price: 340,  dmg: 75,  cd: 640,  pellets: 1, spread: 0.01, speed: 40, life: 1.0,  pierce: 1, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Sokin va aniq: 2 ta zombini birdan teshadi." },
  { id: 'shotgun',  name: "Ov miltig'i",   price: 420,  dmg: 14,  cd: 850,  pellets: 7, spread: 0.5,  speed: 24, life: 0.45, pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Yaqinda 7 ta zarra bilan yuzlab zarar beradi." },
  { id: 'rifle',    name: 'Avtomat miltiq', price: 700, dmg: 24,  cd: 120,  pellets: 1, spread: 0.05, speed: 34, life: 1.2,  pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "Aniq, tez va uzoqqa yetadi. Eng yaxshi universal qurol." },
  { id: 'sniper',   name: 'Snayper',       price: 950,  dmg: 140, cd: 1100, pellets: 1, spread: 0,    speed: 60, life: 0.9,  pierce: 3, splash: 0,   sdmg: 0,   kind: 'sniper',
    desc: "Bitta o'q bilan 4 ta zombini teshib o'tadi." },
  { id: 'flame',    name: 'Olov sochgich', price: 1300, dmg: 7,   cd: 40,   pellets: 1, spread: 0.35, speed: 14, life: 0.4,  pierce: 5, splash: 0,   sdmg: 0,   kind: 'flame',
    desc: "Qisqa masofada olov oqimi, ko'p zombini birdan yoqadi." },
  { id: 'rocket',   name: 'Raketa otar',   price: 1800, dmg: 60,  cd: 1300, pellets: 1, spread: 0.01, speed: 17, life: 1.6,  pierce: 0, splash: 3.6, sdmg: 150, kind: 'rocket',
    desc: "Portlaydi: zombilar to'dasini bir zarbada yo'q qiladi." },
  { id: 'minigun',  name: 'Minigan',       price: 2500, dmg: 13,  cd: 40,   pellets: 1, spread: 0.16, speed: 32, life: 1.0,  pierce: 0, splash: 0,   sdmg: 0,   kind: 'normal',
    desc: "O'q yomg'iri: juda tez va to'xtovsiz." },
  { id: 'grenade',  name: 'Granata otar',  price: 3000, dmg: 40,  cd: 1500, pellets: 1, spread: 0.02, speed: 18, life: 1.1,  pierce: 0, splash: 4.8, sdmg: 240, kind: 'rocket',
    desc: "Katta radiusli portlash. Boss va to'dalar uchun." },
  { id: 'laser',    name: 'Lazer miltiq',  price: 3800, dmg: 22,  cd: 55,   pellets: 1, spread: 0.02, speed: 80, life: 0.6,  pierce: 3, splash: 0,   sdmg: 0,   kind: 'laser',
    desc: "Zudlik bilan uchadigan, to'xtovsiz lazer nuri." },
  { id: 'plasma',   name: 'Plazma to\'pi',  price: 5000, dmg: 40,  cd: 180,  pellets: 1, spread: 0.06, speed: 30, life: 1.0,  pierce: 0, splash: 2.4, sdmg: 90,  kind: 'plasma',
    desc: "Tez otadi va har o'q kichik portlash qiladi." },
  { id: 'railgun',  name: 'Reylgan',       price: 7500, dmg: 420, cd: 1400, pellets: 1, spread: 0,    speed: 100, life: 0.6, pierce: 25, splash: 0,  sdmg: 0,   kind: 'sniper',
    desc: "Butun saf zombini bir o'q bilan teshib o'tadi. Eng kuchli." }
];
const BY_ID = Object.fromEntries(WEAPONS.map(w => [w.id, w]));

/* Kuchaytirish (upgrade): har bir qurolni 5 darajagacha oshirish mumkin.
 * Har daraja: zarar +25%, otish oralig'i -6%. Qurol qo'lda ham kattalashadi. */
const UPGRADE = { max: 5, dmgPer: 0.25, cdPer: 0.06 };
const upgradeCost = (w, lvl) => Math.round((w.price * 0.4 + 80) * (1 + lvl * 0.8) / 5) * 5;
const upgraded = (w, lvl) => ({
  dmg: w.dmg * (1 + UPGRADE.dmgPer * lvl),
  sdmg: w.sdmg * (1 + UPGRADE.dmgPer * lvl),
  cd: w.cd * (1 - UPGRADE.cdPer * lvl)
});
module.exports = { WEAPONS, BY_ID, UPGRADE, upgradeCost, upgraded };
