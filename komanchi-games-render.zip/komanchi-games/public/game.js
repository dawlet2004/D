(() => {
'use strict';

/* ================= Umumiy ================= */
const $ = id => document.getElementById(id);
const socket = io();
const SPAWN = { left: { x: -10, z: 0 }, right: { x: 10, z: 0 } };
const COLORS = { left: 0xd94040, right: 0x3d7fe0 };
const ENTER_FROM = 26;      // o'yinchi maydondan tashqarida shu joydan kirib keladi
const ENTER_SPEED = 6.2;
const BULLET_Y = 1.95;

let mySide = null, roomCode = null;
let phase = 'lobby';        // lobby | waiting | countdown | playing | over
let lastRoom = null;
let countdownTimer = null;

/* ================= 3D sahna ================= */
const canvas = $('scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 400);
const camDir = new THREE.Vector3(0, 0.62, 0.78).normalize();
const camTarget = new THREE.Vector3(0, 0.8, 0);
let camDist = 26;
let shake = 0;

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  const hf = 2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2) * camera.aspect);
  camDist = Math.max(24, 16.5 / Math.tan(hf / 2));
  $('rotateHint').hidden = !(h > w && roomCode);
}
window.addEventListener('resize', resize);

// Osmon (gradient)
(function sky() {
  const c = document.createElement('canvas');
  c.width = 2; c.height = 256;
  const g = c.getContext('2d');
  const grad = g.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, '#2b1a4a');
  grad.addColorStop(0.45, '#8c3a7e');
  grad.addColorStop(0.75, '#e0698a');
  grad.addColorStop(1, '#f7b267');
  g.fillStyle = grad; g.fillRect(0, 0, 2, 256);
  scene.background = new THREE.CanvasTexture(c);
})();

// Yorug'lik
scene.add(new THREE.HemisphereLight(0xffd9b0, 0x6b4a7a, 0.75));
const sun = new THREE.DirectionalLight(0xffc58a, 0.95);
sun.position.set(-12, 20, 12);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -24, right: 24, top: 16, bottom: -16, near: 1, far: 60 });
scene.add(sun);

const lam = c => new THREE.MeshLambertMaterial({ color: c });
function box(w, h, d, color, x, y, z, parent = scene, shadow = true) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), lam(color));
  m.position.set(x, y, z);
  m.castShadow = shadow; m.receiveShadow = true;
  parent.add(m);
  return m;
}

// Yer
const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 160), lam(0xd9a45f));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true;
scene.add(ground);
const arena = new THREE.Mesh(new THREE.PlaneGeometry(31, 17.5), lam(0xefc98c));
arena.rotation.x = -Math.PI / 2; arena.position.y = 0.02; arena.receiveShadow = true;
scene.add(arena);

// Boshlanish doiralari
for (const side of ['left', 'right']) {
  const ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.4, 32), new THREE.MeshBasicMaterial({ color: COLORS[side] }));
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(SPAWN[side].x, 0.04, SPAWN[side].z);
  scene.add(ring);
}

// Maydon chetidagi panjara
for (let x = -14; x <= 14; x += 4) {
  box(0.25, 1, 0.25, 0x7a4a2a, x, 0.5, -8.9);
  box(0.25, 1, 0.25, 0x7a4a2a, x, 0.5, 8.9);
}
box(28.4, 0.12, 0.12, 0x7a4a2a, 0, 0.8, -8.9);
box(28.4, 0.12, 0.12, 0x7a4a2a, 0, 0.8, 8.9);

// Kirish darvozalari (chap va o'ng)
for (const side of ['left', 'right']) {
  const sx = side === 'left' ? -1 : 1;
  box(0.4, 3.6, 0.4, 0x6a3f22, sx * 15.6, 1.8, -2.4);
  box(0.4, 3.6, 0.4, 0x6a3f22, sx * 15.6, 1.8, 2.4);
  box(0.5, 0.4, 5.6, 0x6a3f22, sx * 15.6, 3.7, 0);
  box(0.12, 0.9, 4.2, COLORS[side], sx * 15.6, 3.0, 0, scene, false);
}

// Kaktuslar, toshlar, tog'lar
function cactus(x, z, s) {
  const g = new THREE.Group();
  const m = lam(0x4f8a5b);
  const part = (geo, px, py, pz, rz) => {
    const o = new THREE.Mesh(geo, m);
    o.position.set(px, py, pz); o.rotation.z = rz || 0; o.castShadow = true; g.add(o);
  };
  part(new THREE.CylinderGeometry(0.35, 0.4, 3, 8), 0, 1.5, 0);
  part(new THREE.CylinderGeometry(0.2, 0.2, 0.9, 8), 0.65, 1.7, 0, Math.PI / 2);
  part(new THREE.CylinderGeometry(0.2, 0.2, 1, 8), 1.05, 2.1, 0);
  part(new THREE.CylinderGeometry(0.2, 0.2, 0.8, 8), -0.6, 1.2, 0, Math.PI / 2);
  part(new THREE.CylinderGeometry(0.2, 0.2, 0.9, 8), -0.98, 1.6, 0);
  g.position.set(x, 0, z); g.scale.setScalar(s);
  scene.add(g);
}
[[-20, -12, 1.2], [18, -13, 1], [-26, 6, 1.4], [25, 9, 1.1], [-8, -16, 0.9], [9, -18, 1.3], [-23, -4, 0.8]].forEach(a => cactus(...a));

[[-17, 12, 1.4], [14, 13, 1.8], [22, -8, 1.2], [-24, -10, 2], [3, -14, 1.1]].forEach(([x, z, s]) => {
  const r = new THREE.Mesh(new THREE.DodecahedronGeometry(1, 0), lam(0x8a6a5a));
  r.position.set(x, s * 0.5, z); r.scale.set(s, s * 0.7, s); r.rotation.y = x;
  r.castShadow = true; r.receiveShadow = true; scene.add(r);
});

[[-55, -62, 22, 40, 0x57305f], [-20, -70, 28, 52, 0x472650], [25, -66, 24, 44, 0x57305f],
 [60, -60, 20, 34, 0x472650], [0, -90, 34, 60, 0x3a2048]].forEach(([x, z, r, h, c]) => {
  const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, 5), new THREE.MeshLambertMaterial({ color: c }));
  m.position.set(x, h / 2 - 1, z); scene.add(m);
});

// Quyosh
const sunDisc = new THREE.Mesh(new THREE.CircleGeometry(10, 48), new THREE.MeshBasicMaterial({ color: 0xffd08a }));
sunDisc.position.set(10, 14, -110); scene.add(sunDisc);
const halo = new THREE.Mesh(new THREE.CircleGeometry(18, 48), new THREE.MeshBasicMaterial({ color: 0xffb070, transparent: true, opacity: 0.35 }));
halo.position.set(10, 14, -111); scene.add(halo);

// Dumalab yuruvchi o't (jonli animatsiya)
const weed = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 1),
  new THREE.MeshBasicMaterial({ color: 0x8a5a2a, wireframe: true }));
weed.position.set(-34, 0.7, -11); scene.add(weed);

/* ================= Jangchi modeli ================= */
function makeFighter(side) {
  const mats = [];
  const mat = c => { const m = new THREE.MeshLambertMaterial({ color: c, emissive: 0x000000 }); mats.push(m); return m; };
  const holder = new THREE.Group();
  const rig = new THREE.Group();
  holder.add(rig);

  const skin = mat(0xf1c7a0), shirt = mat(COLORS[side]), pants = mat(0x3a2d3f),
        hatM = mat(0x5a3a22), dark = mat(0x1d1420), team = mat(COLORS[side]);
  const add = (parent, geo, m, x, y, z) => {
    const o = new THREE.Mesh(geo, m);
    o.position.set(x, y, z); o.castShadow = true; parent.add(o); return o;
  };

  const legL = new THREE.Group(); legL.position.set(-0.25, 1.0, 0); rig.add(legL);
  const legR = new THREE.Group(); legR.position.set(0.25, 1.0, 0); rig.add(legR);
  add(legL, new THREE.BoxGeometry(0.38, 1.0, 0.42), pants, 0, -0.5, 0);
  add(legR, new THREE.BoxGeometry(0.38, 1.0, 0.42), pants, 0, -0.5, 0);
  add(legL, new THREE.BoxGeometry(0.4, 0.16, 0.55), dark, 0, -0.95, 0.06);
  add(legR, new THREE.BoxGeometry(0.4, 0.16, 0.55), dark, 0, -0.95, 0.06);

  add(rig, new THREE.BoxGeometry(0.95, 1.05, 0.55), shirt, 0, 1.55, 0);
  add(rig, new THREE.BoxGeometry(1.0, 0.14, 0.6), dark, 0, 1.08, 0);          // kamar

  add(rig, new THREE.SphereGeometry(0.32, 16, 12), skin, 0, 2.28, 0);
  add(rig, new THREE.BoxGeometry(0.06, 0.06, 0.05), dark, -0.11, 2.34, 0.29);   // ko'zlar
  add(rig, new THREE.BoxGeometry(0.06, 0.06, 0.05), dark, 0.11, 2.34, 0.29);
  add(rig, new THREE.BoxGeometry(0.62, 0.24, 0.1), team, 0, 2.12, 0.26);       // bandana
  add(rig, new THREE.CylinderGeometry(0.62, 0.62, 0.07, 20), hatM, 0, 2.52, 0); // shlyapa
  add(rig, new THREE.CylinderGeometry(0.33, 0.36, 0.34, 16), hatM, 0, 2.72, 0);
  add(rig, new THREE.CylinderGeometry(0.37, 0.37, 0.08, 16), team, 0, 2.6, 0);

  const armL = new THREE.Group(); armL.position.set(-0.6, 1.95, 0); rig.add(armL);
  const armR = new THREE.Group(); armR.position.set(0.6, 1.95, 0); rig.add(armR);
  add(armL, new THREE.BoxGeometry(0.26, 0.8, 0.26), shirt, 0, -0.4, 0);
  add(armR, new THREE.BoxGeometry(0.26, 0.8, 0.26), shirt, 0, -0.4, 0);
  add(armL, new THREE.BoxGeometry(0.22, 0.2, 0.22), skin, 0, -0.9, 0);
  add(armR, new THREE.BoxGeometry(0.22, 0.2, 0.22), skin, 0, -0.9, 0);
  add(armR, new THREE.BoxGeometry(0.14, 0.6, 0.18), dark, 0, -1.15, 0);        // to'pponcha
  const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffe08a }));
  muzzle.position.set(0, -1.55, 0); muzzle.visible = false; armR.add(muzzle);

  scene.add(holder);
  const sx = SPAWN[side].x;
  return {
    side, holder, rig, legL, legR, armL, armR, muzzle, mats,
    present: false, alive: true, hp: 100, name: '',
    x: sx, z: 0, tx: sx, tz: 0, yaw: side === 'left' ? Math.PI / 2 : -Math.PI / 2,
    entering: false, mv: 0, kick: 0, flash: 0, fall: 0, seed: Math.random() * 10
  };
}
const fighters = { left: makeFighter('left'), right: makeFighter('right') };
fighters.left.present = fighters.right.present = true; // lobbida ikkalasi ko'rinib turadi

function angleLerp(a, b, k) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * k;
}

function updateFighter(f, dt, t) {
  f.holder.visible = f.present;
  if (!f.present) return;
  const px = f.x, pz = f.z;

  if (f.entering) {
    const dx = f.tx - f.x, dz = f.tz - f.z, d = Math.hypot(dx, dz), step = ENTER_SPEED * dt;
    if (d <= step) { f.x = f.tx; f.z = f.tz; f.entering = false; }
    else { f.x += dx / d * step; f.z += dz / d * step; }
  } else {
    const k = 1 - Math.exp(-dt * 18);
    f.x += (f.tx - f.x) * k; f.z += (f.tz - f.z) * k;
  }
  const speed = Math.hypot(f.x - px, f.z - pz) / Math.max(dt, 0.001);
  f.mv += (Math.min(speed / 5, 1) - f.mv) * Math.min(1, dt * 12);
  f.holder.position.set(f.x, 0, f.z);

  // qaramoq: raqibga (yoki markazga)
  const opp = fighters[f.side === 'left' ? 'right' : 'left'];
  let want;
  if (f.entering || !opp.present) want = f.side === 'left' ? Math.PI / 2 : -Math.PI / 2;
  else want = Math.atan2(opp.x - f.x, opp.z - f.z);
  if (f.alive) f.yaw = angleLerp(f.yaw, want, Math.min(1, dt * 10));
  f.holder.rotation.y = f.yaw;

  // animatsiya
  const sw = Math.sin(t * 11 + f.seed) * 0.75 * f.mv;
  f.legL.rotation.x = sw;
  f.legR.rotation.x = -sw;
  f.rig.position.y = Math.abs(Math.sin(t * 11 + f.seed)) * 0.09 * f.mv;
  f.rig.scale.y = 1 + Math.sin(t * 2 + f.seed) * 0.012;

  f.kick = Math.max(0, f.kick - dt * 7);
  f.armR.rotation.x = -1.57 + f.kick * 0.75 + Math.sin(t * 11 + f.seed) * 0.05 * f.mv;
  f.armL.rotation.x = -1.2 - Math.sin(t * 11 + f.seed) * 0.12 * f.mv;
  f.muzzle.visible = f.kick > 0.7;
  f.rig.position.z = -f.kick * 0.1;

  // yiqilish
  if (!f.alive) {
    f.fall = Math.min(1, f.fall + dt * 2.2);
    const e = 1 - Math.pow(1 - f.fall, 3);
    f.rig.rotation.x = -Math.PI / 2 * e;
    f.rig.position.y = 0.28 * e;
    f.armR.rotation.x = 0.4 * e; f.armL.rotation.x = -0.3 * e;
    f.legL.rotation.x = 0; f.legR.rotation.x = 0;
  } else {
    f.fall = 0; f.rig.rotation.x = 0;
  }

  // zarba yaltirashi
  f.flash = Math.max(0, f.flash - dt);
  const em = f.flash > 0 ? 0x992211 : 0x000000;
  for (const m of f.mats) m.emissive.setHex(em);
}

/* ================= O'qlar va zarralar ================= */
const bulletMeshes = new Map();
const bulletGeo = new THREE.BoxGeometry(0.12, 0.12, 0.8);
const bulletMat = new THREE.MeshBasicMaterial({ color: 0xffd36b });

function syncBullets(list) {
  const seen = new Set();
  for (const [id, x, z] of list) {
    seen.add(id);
    let b = bulletMeshes.get(id);
    if (!b) {
      b = { mesh: new THREE.Mesh(bulletGeo, bulletMat), x, z };
      b.mesh.position.set(x, BULLET_Y, z);
      scene.add(b.mesh);
      bulletMeshes.set(id, b);
    }
    const dx = x - b.x, dz = z - b.z;
    if (Math.abs(dx) + Math.abs(dz) > 0.001) b.mesh.rotation.y = Math.atan2(dx, dz);
    b.x = x; b.z = z;
    b.mesh.position.set(x, BULLET_Y, z);
  }
  for (const [id, b] of bulletMeshes) {
    if (!seen.has(id)) { scene.remove(b.mesh); bulletMeshes.delete(id); }
  }
}
function clearBullets() { syncBullets([]); }

const particles = [];
const pGeo = new THREE.BoxGeometry(0.16, 0.16, 0.16);
function burst(x, y, z, colors, n) {
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(pGeo, new THREE.MeshBasicMaterial({ color: colors[i % colors.length], transparent: true }));
    m.position.set(x, y, z);
    scene.add(m);
    particles.push({ m, vx: (Math.random() - 0.5) * 7, vy: Math.random() * 6 + 2, vz: (Math.random() - 0.5) * 7, life: 0.7 });
  }
}
function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life -= dt; p.vy -= 18 * dt;
    p.m.position.x += p.vx * dt; p.m.position.y = Math.max(0.05, p.m.position.y + p.vy * dt); p.m.position.z += p.vz * dt;
    p.m.material.opacity = Math.max(0, p.life / 0.7);
    if (p.life <= 0) { scene.remove(p.m); p.m.material.dispose(); particles.splice(i, 1); }
  }
}

/* ================= Ovoz (WebAudio) ================= */
let actx = null;
function initAudio() {
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
  } catch (e) { /* ovoz ixtiyoriy */ }
}
function sfxShot() {
  if (!actx) return;
  const n = Math.floor(actx.sampleRate * 0.14), buf = actx.createBuffer(1, n, actx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
  const src = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
  f.type = 'lowpass'; f.frequency.value = 1800; g.gain.value = 0.25;
  src.buffer = buf; src.connect(f); f.connect(g); g.connect(actx.destination); src.start();
}
function sfxHit() {
  if (!actx) return;
  const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime;
  o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.18);
  g.gain.setValueAtTime(0.35, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
  o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + 0.22);
}

/* ================= Render halqasi ================= */
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  const t = now / 1000;

  updateFighter(fighters.left, dt, t);
  updateFighter(fighters.right, dt, t);
  updateParticles(dt);

  weed.position.x += dt * 3.2;
  weed.rotation.z -= dt * 4;
  weed.position.y = 0.7 + Math.abs(Math.sin(t * 5)) * 0.25;
  if (weed.position.x > 34) weed.position.x = -34;

  shake = Math.max(0, shake - dt * 2.5);
  const sway = Math.sin(t * 0.15) * 1.6;
  camera.position.set(
    camTarget.x + camDir.x * camDist + sway + (Math.random() - 0.5) * shake,
    camTarget.y + camDir.y * camDist + (Math.random() - 0.5) * shake,
    camTarget.z + camDir.z * camDist
  );
  camera.lookAt(camTarget);
  renderer.render(scene, camera);
}
resize();
requestAnimationFrame(frame);

/* ================= HUD / banner ================= */
function setBanner(big, sub, pop) {
  const el = $('banner');
  if (!big && !sub) { el.hidden = true; return; }
  el.hidden = false;
  const b = $('bannerBig');
  b.textContent = big || '';
  b.classList.remove('pop');
  if (pop) { void b.offsetWidth; b.classList.add('pop'); }
  $('bannerSub').textContent = sub || '';
}

function renderHud() {
  if (!lastRoom) return;
  const bySide = {};
  lastRoom.players.forEach(p => bySide[p.side] = p);
  for (const s of ['left', 'right']) {
    const p = bySide[s], f = fighters[s];
    const el = $(s === 'left' ? 'nameLeft' : 'nameRight');
    el.textContent = p ? p.name + (s === mySide ? ' (siz)' : '') : 'Kutilmoqda...';
    f.name = p ? p.name : '';
    $(s === 'left' ? 'barLeft' : 'barRight').style.width = (p ? f.hp : 0) + '%';
  }
}

function showWaiting() {
  setBanner('Raqib kutilmoqda...', 'Do\'stingizga xona kodini yuboring: ' + roomCode);
}

/* ================= Tarmoq hodisalari ================= */
socket.on('room', info => {
  lastRoom = info;
  const present = {};
  info.players.forEach(p => present[p.side] = true);
  for (const s of ['left', 'right']) {
    const f = fighters[s];
    f.present = !!present[s];
    if (info.state === 'waiting' && f.present) {
      f.alive = true; f.hp = 100; f.entering = false; f.fall = 0;
      f.tx = SPAWN[s].x; f.tz = SPAWN[s].z; f.x = f.tx; f.z = f.tz;
    }
  }
  if (info.state === 'waiting') {
    phase = 'waiting'; updateTouch();
    clearTimeout(countdownTimer);
    clearBullets();
    $('overlay').hidden = true;
    if (roomCode) showWaiting();
  }
  renderHud();
});

socket.on('start', data => {
  phase = 'countdown'; updateTouch();
  $('overlay').hidden = true;
  clearBullets();
  for (const s of ['left', 'right']) {
    const f = fighters[s];
    f.present = true; f.alive = true; f.hp = 100; f.fall = 0; f.flash = 0;
    f.x = s === 'left' ? -ENTER_FROM : ENTER_FROM; f.z = 0;
    f.tx = SPAWN[s].x; f.tz = SPAWN[s].z;
    f.entering = true;
  }
  renderHud();
  // sanoq
  let n = data.countdown;
  const sideTxt = mySide === 'left' ? "Siz chap tomondan kirasiz" : "Siz o'ng tomondan kirasiz";
  setBanner(String(n), sideTxt, true);
  clearInterval(countdownTimer);
  countdownTimer = setInterval(() => {
    n--;
    if (n > 0) setBanner(String(n), sideTxt, true);
    else clearInterval(countdownTimer);
  }, 1000);
});

socket.on('go', () => {
  phase = 'playing'; updateTouch();
  clearInterval(countdownTimer);
  setBanner('OTING!', '', true);
  setTimeout(() => { if (phase === 'playing') setBanner(); }, 900);
});

socket.on('state', s => {
  if (phase !== 'playing' && phase !== 'over') return;
  for (const p of s.p) {
    const f = fighters[p.s];
    f.tx = p.x; f.tz = p.z; f.hp = p.hp;
  }
  syncBullets(s.b);
  renderHud();
});

socket.on('shot', d => {
  fighters[d.side].kick = 1;
  sfxShot();
});

socket.on('hit', d => {
  const f = fighters[d.side];
  f.flash = 0.18; f.hp = d.hp;
  if (d.hp <= 0) f.alive = false;
  burst(d.x, 1.7, d.z, [0xd94040, 0xffd36b, 0xefc98c], 14);
  shake = 0.5;
  sfxHit();
  renderHud();
});

socket.on('over', d => {
  phase = 'over'; updateTouch();
  const won = d.winner === mySide;
  const loser = d.winner === 'left' ? 'right' : 'left';
  fighters[loser].alive = false; fighters[loser].hp = 0;
  renderHud();
  setTimeout(() => {
    if (phase !== 'over') return;
    $('overTitle').textContent = won ? "G'alaba!" : "Mag'lubiyat";
    $('overSub').textContent = won ? 'Siz raqibni yengdingiz.' : (d.names[d.winner] + ' sizni yengdi.');
    $('rematchBtn').disabled = false;
    $('rematchBtn').textContent = "Qayta o'ynash";
    $('overlay').hidden = false;
  }, 1300);
});

/* ================= Lobbi ================= */
const nameInput = $('nameInput'), codeInput = $('codeInput');
try { nameInput.value = localStorage.getItem('kd_name') || ''; } catch (e) {}
const urlCode = new URLSearchParams(location.search).get('room');
if (urlCode) codeInput.value = urlCode.toUpperCase().slice(0, 4);

function getName() {
  const n = nameInput.value.trim();
  try { localStorage.setItem('kd_name', n); } catch (e) {}
  return n;
}
function lobbyError(msg) { $('lobbyError').textContent = msg || ''; }

function enterRoom(res) {
  if (!res || !res.ok) { lobbyError(res && res.error || 'Xatolik yuz berdi.'); return; }
  mySide = res.side; roomCode = res.code;
  phase = 'waiting'; updateTouch();
  $('lobby').hidden = true;
  $('hud').hidden = false;
  $('chatToggle').hidden = false;
  $('roomCode').textContent = roomCode;
  if (window.innerWidth > 760) openChat(true);
  history.replaceState(null, '', '?room=' + roomCode);
  resize();
  renderHud();
  if (!lastRoom || lastRoom.players.length < 2) showWaiting();
}

$('createBtn').addEventListener('click', () => {
  initAudio(); lobbyError('');
  socket.emit('create', getName(), enterRoom);
});
function doJoin() {
  initAudio(); lobbyError('');
  const code = codeInput.value.trim().toUpperCase();
  if (code.length !== 4) { lobbyError('Kod 4 ta belgidan iborat.'); return; }
  socket.emit('join', code, getName(), enterRoom);
}
$('joinBtn').addEventListener('click', doJoin);
$('lobbyForm').addEventListener('submit', e => { e.preventDefault(); doJoin(); });
codeInput.addEventListener('input', () => { codeInput.value = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });

$('copyBtn').addEventListener('click', () => {
  const link = location.origin + '/?room=' + roomCode;
  const done = () => { $('copyBtn').textContent = 'Nusxalandi'; setTimeout(() => $('copyBtn').textContent = 'Nusxa', 1200); };
  if (navigator.clipboard) navigator.clipboard.writeText(link).then(done, done); else done();
});

$('rematchBtn').addEventListener('click', () => {
  socket.emit('rematch');
  $('rematchBtn').disabled = true;
  $('rematchBtn').textContent = 'Raqib kutilmoqda...';
});
$('leaveBtn').addEventListener('click', () => {
  socket.emit('leave');
  history.replaceState(null, '', location.pathname);
  location.reload();
});

/* ================= Chat ================= */
const chatEl = $('chat'), logEl = $('chatLog'), chatInput = $('chatInput');
let unread = 0;
function openChat(open) {
  chatEl.hidden = !open;
  if (open) { unread = 0; $('badge').hidden = true; logEl.scrollTop = logEl.scrollHeight; }
}
$('chatToggle').addEventListener('click', () => openChat(chatEl.hidden));

socket.on('chat', m => {
  const div = document.createElement('div');
  if (m.sys) {
    div.className = 'msg sys';
    div.textContent = m.text;
  } else {
    div.className = 'msg ' + m.side + (m.side === mySide ? ' me' : '');
    const b = document.createElement('b'); b.textContent = m.name;
    const s = document.createElement('span'); s.textContent = m.text;
    div.append(b, s);
  }
  logEl.appendChild(div);
  while (logEl.children.length > 100) logEl.removeChild(logEl.firstChild);
  logEl.scrollTop = logEl.scrollHeight;
  if (chatEl.hidden && !m.sys) {
    unread++;
    $('badge').textContent = unread; $('badge').hidden = false;
  }
});

$('chatForm').addEventListener('submit', e => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (text) socket.emit('chat', text);
  chatInput.value = '';
});
chatInput.addEventListener('keydown', e => { if (e.key === 'Escape') chatInput.blur(); });

/* ================= Boshqaruv ================= */
const keys = { u: 0, d: 0, l: 0, r: 0 };
let lastSent = '0000';
function sendInput() {
  const k = '' + keys.u + keys.d + keys.l + keys.r;
  if (k !== lastSent) { lastSent = k; socket.emit('input', keys); }
}
function releaseAll() { keys.u = keys.d = keys.l = keys.r = 0; sendInput(); stopFire(); }

let fireTimer = null;
function shoot() { if (phase === 'playing') socket.emit('shoot'); }
function startFire() { if (fireTimer) return; shoot(); fireTimer = setInterval(shoot, 120); }
function stopFire() { clearInterval(fireTimer); fireTimer = null; }

const keyMap = { KeyW: 'u', ArrowUp: 'u', KeyS: 'd', ArrowDown: 'd', KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r' };
const typing = () => { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA'); };

window.addEventListener('keydown', e => {
  if (typing() || !roomCode) return;
  if (keyMap[e.code]) { keys[keyMap[e.code]] = 1; sendInput(); e.preventDefault(); }
  else if (e.code === 'Space') { startFire(); e.preventDefault(); }
  else if (e.code === 'Enter') { openChat(true); chatInput.focus(); e.preventDefault(); }
});
window.addEventListener('keyup', e => {
  if (keyMap[e.code]) { keys[keyMap[e.code]] = 0; sendInput(); }
  else if (e.code === 'Space') stopFire();
});
window.addEventListener('blur', releaseAll);

canvas.addEventListener('pointerdown', () => { if (roomCode) startFire(); });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => canvas.addEventListener(ev, stopFire));

// Telefon tugmalari

function makeStick(el, onMove, onEnd) {
  const knob = el.querySelector('.knob');
  let pid = null, cx = 0, cy = 0;
  const R = () => el.getBoundingClientRect().width * 0.34;
  const set = (dx, dy) => {
    const r = R(), m = Math.hypot(dx, dy), k = m > r ? r / m : 1;
    dx *= k; dy *= k;
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    onMove(dx / r, dy / r);
  };
  el.addEventListener('pointerdown', e => {
    if (pid !== null) return;
    pid = e.pointerId; try { el.setPointerCapture(pid); } catch (err) {}
    const b = el.getBoundingClientRect(); cx = b.left + b.width / 2; cy = b.top + b.height / 2;
    set(e.clientX - cx, e.clientY - cy); e.preventDefault();
  });
  el.addEventListener('pointermove', e => { if (e.pointerId === pid) { set(e.clientX - cx, e.clientY - cy); e.preventDefault(); } });
  const end = e => { if (e.pointerId !== pid) return; pid = null; knob.style.transform = 'translate(0,0)'; onEnd(); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  return { reset() { pid = null; knob.style.transform = 'translate(0,0)'; } };
}

const showTouch = window.matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window;
const moveStick = makeStick($('moveStick'), (x, y) => {
  keys.l = +(x < -0.35); keys.r = +(x > 0.35); keys.u = +(y < -0.35); keys.d = +(y > 0.35); sendInput();
}, () => { keys.u = keys.d = keys.l = keys.r = 0; sendInput(); });
function updateTouch() {
  const on = showTouch && !!roomCode && (phase === 'countdown' || phase === 'playing');
  $('touch').hidden = !on;
  if (!on && showTouch) { keys.u = keys.d = keys.l = keys.r = 0; stopFire(); moveStick.reset(); }
}
const fireBtn = $('fireBtn');
fireBtn.addEventListener('pointerdown', e => { e.preventDefault(); fireBtn.classList.add('on'); startFire(); });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev =>
  fireBtn.addEventListener(ev, () => { fireBtn.classList.remove('on'); stopFire(); }));

socket.on('disconnect', () => { setBanner('Aloqa uzildi', 'Sahifani yangilang va qayta kiring.'); });
})();
